function Erettsegi(pontok) {
    var osszpontszam = 0;
    for (var i = 0; i < pontok.length; i++) {
        osszpontszam += pontok[i];
    }
    var jegy = 1;
    if (osszpontszam >= 40 && osszpontszam < 60) {
        jegy = 2;
    }
    else if (osszpontszam >= 60 && osszpontszam < 80) {
        jegy = 3;
    }
    else if (osszpontszam >= 80 && osszpontszam < 120) {
        jegy = 4;
    }
    else if (osszpontszam >= 120 && osszpontszam <= 150) {
        jegy = 5;
    }
    return [osszpontszam, jegy];
}
// Teszteset:
var pontok = [75, 80, 95, 110, 65]; // A modulok eredményei
var eredmeny = Erettsegi(pontok);
console.log("Összpontszám:", eredmeny[0]);
console.log("Jegy:", eredmeny[1]);
