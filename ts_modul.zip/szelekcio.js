function HosegriadoSzint(nap1, nap2, nap3) {
    var atlagHomerseklet = (nap1 + nap2 + nap3) / 3;
    if (atlagHomerseklet >= 27) {
        return 3;
    }
    else if (atlagHomerseklet >= 25) {
        return 2;
    }
    else if (atlagHomerseklet > 0) {
        return 1;
    }
    else {
        return 0;
    }
}
// Teszteset:
var nap1 = 28;
var nap2 = 26;
var nap3 = 24;
var riadoSzint = HosegriadoSzint(nap1, nap2, nap3);
console.log("Hőségriadó szint:", riadoSzint);
