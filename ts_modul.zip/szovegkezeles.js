function LeetKod(vizsgaltSzoveg) {
    var atalakitottSzoveg = "";
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        var karakter = vizsgaltSzoveg[i];
        switch (karakter) {
            case "i":
            case "I":
                atalakitottSzoveg += "1";
                break;
            case "o":
            case "O":
                atalakitottSzoveg += "0";
                break;
            case "a":
            case "A":
                atalakitottSzoveg += "4";
                break;
            case "e":
            case "E":
                atalakitottSzoveg += "3";
                break;
            default:
                atalakitottSzoveg += karakter;
                break;
        }
    }
    return atalakitottSzoveg;
}
var vizsgaltSzoveg = "Hello, World!";
var atalakitottSzoveg = LeetKod(vizsgaltSzoveg);
console.log("Átalakított szöveg:", atalakitottSzoveg);
