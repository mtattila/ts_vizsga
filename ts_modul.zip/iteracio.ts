function OszthatoSzamok(oszto: number, vizsgaltTomb: number[]): number {
  let szamokSzama = 0;

  for (let i = 0; i < vizsgaltTomb.length; i++) {
    if (vizsgaltTomb[i] % oszto === 0) {
      szamokSzama++;
    }
  }

  return szamokSzama;
}

const oszto: number = 3;
const vizsgaltTomb: number[] = [6, 9, 12, 15, 18, 21, 24];

const oszthatoSzamokSzama: number = OszthatoSzamok(oszto, vizsgaltTomb);
console.log("Az osztható számok száma:", oszthatoSzamokSzama);