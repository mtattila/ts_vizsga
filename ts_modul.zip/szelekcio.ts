function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
    const atlagHomerseklet = (nap1 + nap2 + nap3) / 3;
  
    if (atlagHomerseklet >= 27) {
      return 3;
    } else if (atlagHomerseklet >= 25) {
      return 2;
    } else if (atlagHomerseklet > 0) {
      return 1;
    } else {
      return 0;
    }
  }
  

  const nap1: number = 28;
  const nap2: number = 26; 
  const nap3: number = 24; 
  
  const riadoSzint: number = HosegriadoSzint(nap1, nap2, nap3);
  console.log("Hőségriadó szint:", riadoSzint);