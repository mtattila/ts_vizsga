function OszthatoSzamok(oszto, vizsgaltTomb) {
    var szamokSzama = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % oszto === 0) {
            szamokSzama++;
        }
    }
    return szamokSzama;
}
var oszto = 3;
var vizsgaltTomb = [6, 9, 12, 15, 18, 21, 24];
var oszthatoSzamokSzama = OszthatoSzamok(oszto, vizsgaltTomb);
console.log("Az osztható számok száma:", oszthatoSzamokSzama);
