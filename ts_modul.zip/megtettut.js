function MegtettUt(sebesseg, ido) {
    var ut = sebesseg * ido;
    return ut;
}
var sebesseg = 50;
var ido = 2;
var megtettUt = MegtettUt(sebesseg, ido);
console.log("Megtett út:", megtettUt, "km");
