function Erettsegi(pontok: number[]): [number, number] {
    let osszpontszam = 0;
  
    for (let i = 0; i < pontok.length; i++) {
      osszpontszam += pontok[i];
    }
  
    let jegy = 1;
  
    if (osszpontszam >= 40 && osszpontszam < 60) {
      jegy = 2;
    } else if (osszpontszam >= 60 && osszpontszam < 80) {
      jegy = 3;
    } else if (osszpontszam >= 80 && osszpontszam < 120) {
      jegy = 4;
    } else if (osszpontszam >= 120 && osszpontszam <= 150) {
      jegy = 5;
    }
  
    return [osszpontszam, jegy];
  }
  
  // Teszteset:
  const pontok: number[] = [75, 80, 95, 110, 65]; // A modulok eredményei
  
  const eredmeny: [number, number] = Erettsegi(pontok);
  console.log("Összpontszám:", eredmeny[0]);
  console.log("Jegy:", eredmeny[1]);