function MegtettUt(sebesseg: number, ido: number): number {
    const ut = sebesseg * ido;
    return ut;
  }
  

  const sebesseg = 50;
  const ido = 2;
  const megtettUt = MegtettUt(sebesseg, ido);
  console.log("Megtett út:", megtettUt, "km");